/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cefetiny;

/**
 *
 * @author User
 */
public class Metodos {
    Object metodo;

    public Metodos() {
    }

    public Metodos(Object Metodo) {
        this.metodo = metodo;
    }

    public Object getMetodo() {
        return metodo;
    }

    public void setMetodo(Object Metodo) {
        this.metodo = metodo;
    }
    
    
}
